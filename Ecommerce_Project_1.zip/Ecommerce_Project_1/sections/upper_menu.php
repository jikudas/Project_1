<?php $generated_single = $easyfie->generatedPageSingle($token, $slug); 
    // echo "<pre>";
    // print_r($generated_single);
    // exit;
?>
<!-- Begin Article
================================================== -->
<div class="container mt-5">
	<div class="row">
        <?= $generated_single->post ?>
	</div>
</div>
<!-- End Article
================================================== -->